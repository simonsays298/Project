# Project

Pentru a putea rula este nevoie de urmatoarele comenzi pe linux:

pip instal virtualenv
mkvirtualenv my-env
source my-env/bin/activate
pip3 install --user flask sqlalchemy flask-sqlalchemy
export FLASK_APP=run.py

Apoi trebuie rulata comanda ==> flask run


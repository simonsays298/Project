from flask import Flask
from flask.ext.sqlalchemy import SQLAlchemy


# Initialize the app
app = Flask(__name__)

# Load the views
from app import routes

# Load the config file
app.config.from_object['SQLALCHEMY_DATABSE_URI'] = 'sqlite:////tmp/test.db'
db = SQLAlchemy(app)